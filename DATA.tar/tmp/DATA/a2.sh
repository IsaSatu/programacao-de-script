#!/bin/bash
read -p d1 d2
ls ${d1} ${d2} 
