#!/bin/bash
echo 'Amor verus numquam moritur'
