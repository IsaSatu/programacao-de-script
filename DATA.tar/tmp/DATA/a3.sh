#!/bin/bash
D="$1"
D="$2"

echo 'Exibir Diretorios'
ls {d1} {d2} 
