#!/bin/bash 

D="$1"
D="$2"

ls ${d1} ${D2} > /tmp/lista.linda.txt
echo'arquivos salvos em lista linda'
